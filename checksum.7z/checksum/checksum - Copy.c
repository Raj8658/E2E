#include "checksum.h"
#include <stdlib.h>
#include <string.h>

char* calculate_checksum(const char* data, int block_size) {
    int num_blocks = strlen(data) / block_size;
    int checksum = 0;

    // Sum the blocks
    for (int i = 0; i < num_blocks; i++) {
        char block[block_size + 1];
        strncpy(block, data + i * block_size, block_size);
        block[block_size] = '\0';
        checksum += strtol(block, NULL, 2);
    }

    // Handle carry by adding it back to the sum
    while (checksum >> block_size) {
        int carry = checksum >> block_size;
        checksum = (checksum & ((1 << block_size) - 1)) + carry;
    }

    // Invert bits to get the checksum
    checksum = ~checksum & ((1 << block_size) - 1);

    // Convert checksum to binary string
    char* checksum_str = (char*)malloc(block_size + 1);
    for (int i = block_size - 1; i >= 0; i--) {
        checksum_str[i] = (checksum & 1) ? '1' : '0';
        checksum >>= 1;
    }
    checksum_str[block_size] = '\0';

    return checksum_str;
}

int verify_checksum(const char* data_with_checksum, int block_size) {
    int num_blocks = strlen(data_with_checksum) / block_size;
    int checksum = 0;

    // Sum the blocks
    for (int i = 0; i < num_blocks; i++) {
        char block[block_size + 1];
        strncpy(block, data_with_checksum + i * block_size, block_size);
        block[block_size] = '\0';
        checksum += strtol(block, NULL, 2);
    }

    // Handle carry by adding it back to the sum
    while (checksum >> block_size) {
        int carry = checksum >> block_size;
        checksum = (checksum & ((1 << block_size) - 1)) + carry;
    }

    // Check if the checksum is all 1's
    return checksum == (1 << block_size) - 1;
}
