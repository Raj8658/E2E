#ifndef CHECKSUM_H
#define CHECKSUM_H

#include <stdint.h>

char* calculate_checksum(const char* data, int block_size);
int verify_checksum(const char* data_with_checksum, int block_size);

#endif // CHECKSUM_H
